"""Read-only full selected-intermediate census; no selection or publication.

Exact command and input hashes are recorded with the generated census.
"""
from pathlib import Path
import collections,gzip,hashlib,json,sqlite3,time
ROOT=Path('/workspace/scratch/62d1fc8389c4')
IN=ROOT/'validation/round15/input'
OUT=ROOT/'validation/round15/census';OUT.mkdir(exist_ok=True)
s=json.loads((IN/'EVERYDAY-SELECTION.json').read_bytes())
expected=s['selectedMaterial'];material=IN/'selected-everyday.jsonl.gz'
with material.open('rb') as handle: assert hashlib.file_digest(handle,'sha256').hexdigest()==expected['sha256']
assert material.stat().st_size==expected['sizeBytes']
decks={r['deckId']:r for r in s['decks']}
included={k:d['selectedTargets'] for k,d in decks.items() if d['decision'].startswith('publish')}
db=sqlite3.connect(OUT/'census.sqlite3')
db.executescript('''PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA cache_size=-65536;
CREATE TABLE membership(deck TEXT,target TEXT,PRIMARY KEY(deck,target)) WITHOUT ROWID;
CREATE TABLE target(id TEXT PRIMARY KEY,lang TEXT) WITHOUT ROWID;
CREATE TABLE context(deck TEXT,ref TEXT,PRIMARY KEY(deck,ref)) WITHOUT ROWID;
CREATE TABLE source_context(lang TEXT,ref TEXT,PRIMARY KEY(lang,ref)) WITHOUT ROWID;
CREATE TABLE source_content(lang TEXT,h TEXT,PRIMARY KEY(lang,h)) WITHOUT ROWID;
CREATE TABLE candidate(id TEXT PRIMARY KEY) WITHOUT ROWID;
CREATE TABLE origin(lang TEXT,meaning TEXT,cref TEXT,mref TEXT,PRIMARY KEY(lang,meaning,cref,mref)) WITHOUT ROWID;
CREATE TABLE rank(surface TEXT,rank INTEGER,PRIMARY KEY(surface,rank)) WITHOUT ROWID;
''')
metrics={};hist=collections.Counter();attributes=collections.Counter();families=collections.Counter();versions=collections.Counter()
witness={};before_witness={};logical=hashlib.sha256();logicalbytes=total=contexts=origins=0;start=time.monotonic()
with gzip.open(material,'rb') as handle:
 for raw in handle:
  logical.update(raw);logicalbytes+=len(raw);r=json.loads(raw);total+=1
  did=r['deckId'];tid=r['targetId'];lang=r['lang'];meaning=r['meaningLang'];ctx=r['contexts']
  assert did in included and all(r[k]==decks[did][k] for k in ['lang','meaningLang','collection','level'])
  db.execute('INSERT INTO membership VALUES(?,?)',(did,tid));db.execute('INSERT OR IGNORE INTO target VALUES(?,?)',(tid,lang))
  if lang=='pl':db.execute('INSERT OR IGNORE INTO rank VALUES(?,?)',(r['text'].lower(),r['freqRank']))
  m=metrics.setdefault(did,{'deckId':did,'lang':lang,'meaningLang':meaning,'collection':r['collection'],'level':r['level'],'memberships':0,'contexts':0,'origins':0,'logicalBytes':0,'contextsPerMembership':collections.Counter(),'frequencyRankMin':r['freqRank'],'frequencyRankMax':r['freqRank'],'maxTargetUtf16':0,'maxContextUtf16':0,'maxMeaningUtf16':0,'lemmaUnavailable':0})
  m['memberships']+=1;m['contexts']+=len(ctx);m['logicalBytes']+=len(raw);m['contextsPerMembership'][len(ctx)]+=1
  m['frequencyRankMin']=min(m['frequencyRankMin'],r['freqRank']);m['frequencyRankMax']=max(m['frequencyRankMax'],r['freqRank'])
  m['maxTargetUtf16']=max(m['maxTargetUtf16'],len(r['text'].encode('utf-16-le'))//2);m['lemmaUnavailable']+=r['lemmaSource']=='unavailable'
  hist[len(ctx)]+=1
  for c in ctx:
   contexts+=1;db.execute('INSERT INTO context VALUES(?,?)',(did,c['contextId']))
   db.execute('INSERT OR IGNORE INTO source_context VALUES(?,?)',(lang,c['contextId']))
   ch=hashlib.sha256(c['context'].encode('utf8')).hexdigest();db.execute('INSERT OR IGNORE INTO source_content VALUES(?,?)',(lang,ch))
   db.execute('INSERT OR IGNORE INTO candidate VALUES(?)',(c['candidateId'],))
   m['maxContextUtf16']=max(m['maxContextUtf16'],len(c['context'].encode('utf-16-le'))//2)
   m['maxMeaningUtf16']=max(m['maxMeaningUtf16'],len(c['meaning'].encode('utf-16-le'))//2)
   if {lang,meaning}=={'pl','ko'}:
    if lang=='pl':key=(c['contextId'],c['meaningId']);item={'contextId':key[0],'meaningId':key[1],'context':c['context'],'meaning':c['meaning'],'candidateId':c['candidateId']}
    else:key=(c['meaningId'],c['contextId']);item={'contextId':key[0],'meaningId':key[1],'context':c['meaning'],'meaning':c['context'],'candidateId':c['candidateId'],'reverseWitness':True}
    if key in witness:assert witness[key]['context']==item['context'] and witness[key]['meaning']==item['meaning']
    else:witness[key]=item
    if lang=='pl':before_witness[tid]=r
   for o in c['origins']:
    origins+=1;m['origins']+=1;families[o['sourceFamily']]+=1;versions[o['sourceVersion']]+=1
    a=o.get('attribution',{});attributes['contextContributorPresent']+=bool(a.get('contextContributor'));attributes['meaningContributorPresent']+=bool(a.get('meaningContributor'))
    db.execute('INSERT OR IGNORE INTO origin VALUES(?,?,?,?)',(lang,meaning,o['contextRef'],o['meaningRef']))
  if total%50000==0:
   db.commit();print(f'Census: {total:,} memberships, {contexts:,} contexts; {time.monotonic()-start:.1f}s',flush=True)
db.commit()
assert {k:m['memberships'] for k,m in metrics.items()}==included
assert (total,contexts,origins,logicalbytes,logical.hexdigest())==(expected['memberships'],expected['contexts'],expected['origins'],expected['logicalSizeBytes'],expected['logicalSha256'])
count=lambda table:db.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]
perlanguage={lang:{'uniqueTargets':db.execute('SELECT COUNT(*) FROM target WHERE lang=?',(lang,)).fetchone()[0],'uniquePrimarySourceRefs':db.execute('SELECT COUNT(*) FROM source_context WHERE lang=?',(lang,)).fetchone()[0],'uniquePrimarySourceTexts':db.execute('SELECT COUNT(*) FROM source_content WHERE lang=?',(lang,)).fetchone()[0]} for lang in s['admittedInput']['learn']}
summary={'memberships':total,'uniqueGlobalTargets':count('target'),'contexts':contexts,'origins':origins,'uniquePrimarySourceRefsAcrossLearningLanguages':count('source_context'),'uniquePrimarySourceTextsAcrossLearningLanguages':count('source_content'),'uniqueDirectedCandidateIds':count('candidate'),'uniqueDirectedOriginPairs':count('origin'),'includedDecks':len(metrics),'contextsPerMembership':dict(hist),'singleContextMemberships':hist[1],'lemmaUnavailableMemberships':sum(m['lemmaUnavailable'] for m in metrics.values()),'sourceFamilyOriginOccurrences':dict(families),'sourceVersionOriginOccurrences':dict(versions),'contributorCoverageOriginOccurrences':dict(attributes),'compressedBytes':material.stat().st_size,'logicalBytes':logicalbytes,'maxDeckLogicalBytes':max(m['logicalBytes'] for m in metrics.values())}
report={'censusVersion':1,'status':'complete-selected-intermediate-census-passed','automaticCensusPassed':True,'publicationSafe':False,'semanticAccuracyCertified':False,'globalContentFrozen':False,'readAllMembershipRows':True,'input':expected,'sourceVersion':s['admittedInput']['sourceVersion'],'selectionReportSha256':hashlib.sha256((IN/'EVERYDAY-SELECTION.json').read_bytes()).hexdigest(),'analysisScriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'summary':summary,'byLearningLanguage':perlanguage,'deckInventory':[metrics[k] for k in sorted(metrics)],'excludedDecks':[r for r in s['decks'] if not r['decision'].startswith('publish')],'limitations':['Complete selected intermediate census, not a census of release packs or raw source-pool supply.','Unique source counts cover primary retained context references/text; alternative merged origins are counted separately as provenance, not silently treated as distinct observed sentences.','Per-deck logical bytes are raw selected-intermediate row bytes, not download sizes of final application packs.','Contributor presence and source provenance do not certify translation accuracy or pedagogy.','Morphology enrichment is unavailable in this selection; later release-pack generation/acceptance is a separate stage.']}
(OUT/'CENSUS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'pl-ko-witness.json').write_text(json.dumps({'sourceFileSha256':expected['sha256'],'rankScope':'exported Polish target surface ranks only','ranks':{surface:rank for surface,rank in db.execute('SELECT surface,rank FROM rank WHERE surface IN (SELECT surface FROM rank GROUP BY surface HAVING COUNT(*)=1)')},'ambiguousRankSurfaces':[surface for (surface,) in db.execute('SELECT surface FROM rank GROUP BY surface HAVING COUNT(*)>1')],'contexts':list(witness.values()),'retainedPlKoTargets':list(before_witness.values())},ensure_ascii=False,indent=2)+'\n')
print('Census complete:',json.dumps(summary),flush=True)
db.close()
