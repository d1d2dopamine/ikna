"""Bounded diagnostic only; never writes selection, packs, or learner state."""
from pathlib import Path
from collections import Counter
import hashlib,json
import catalogue_core as core
from catalogue_v2 import target_id
from build_catalogue_v2 import phrase_choices
from selection_policy import filter_unique_choices,select_target_ids,choose_contexts
from ingest.model import candidate_id
from segmentation import utf16_length
root=Path('/workspace/scratch/62d1fc8389c4')
path=root/'validation/round15/census/pl-ko-witness.json';w=json.loads(path.read_bytes());ranks=w['ranks'];by_target={};stats=Counter();accepted_refs={}
for c in sorted(w['contexts'],key=lambda c:candidate_id('everyday','pl','ko',c['context'],c['meaning'])):
 stats['witnessCandidatePairs']+=1
 if len(c['context'])<core.MIN_SENTENCE or utf16_length(c['context'])>core.MAX_SENTENCE:stats['sourceLengthRejected']+=1;continue
 if not c['meaning'] or utf16_length(c['meaning'])>core.MAX_TRANSLATION:stats['meaningLengthRejected']+=1;continue
 choices=phrase_choices(c['context'],ranks,'pl',60);choices,rejected,_=filter_unique_choices(c['context'],choices,'pl');stats.update(rejected)
 if not choices:stats['noKnownEligibleChoice']+=1;continue
 stats['witnessesWithKnownEligibleChoices']+=1
 evidence={**c,'candidateId':candidate_id('everyday','pl','ko',c['context'],c['meaning']),'sourceFamilies':['tatoeba'],'alignmentScore':None,'tokenCount':len(core.words(c['context'],'pl'))}
 accepted_refs[c['contextId']]=c
 for rank,surface,tid,level in choices:
  target=by_target.setdefault(tid,{'targetId':tid,'text':surface,'freqRank':rank,'level':level,'lemmaKey':tid,'lemmaSource':'unavailable','sourceFamilies':['tatoeba'],'evidenceContexts':0,'contexts':[]})
  target['evidenceContexts']+=1;target['contexts'].append(evidence)

def greedy(targets,limit):
 used=set();rows=[];loss=0
 for t in targets:
  available=[c for c in t['contexts'] if c['contextId'] not in used]
  chosen,_=choose_contexts(available,limit,0.85,diverse=True,lang='pl')
  if not chosen:loss+=1;continue
  used.update(c['contextId'] for c in chosen)
  rows.append({'targetId':t['targetId'],'text':t['text'],'contextRefs':[c['contextId'] for c in chosen]})
 return {'memberships':len(rows),'reservedContextRefs':len(used),'targetsWithNoUnusedContext':loss,'assignments':rows}

def maximum_matching(targets):
 edges={t['targetId']:sorted({c['contextId'] for c in t['contexts']}) for t in targets};assigned={}
 def visit(tid,seen):
  for ref in edges[tid]:
   if ref in seen:continue
   seen.add(ref)
   if ref not in assigned or visit(assigned[ref],seen):assigned[ref]=tid;return True
  return False
 for t in targets:visit(t['targetId'],set())
 return {'memberships':len(assigned),'assignments':dict(sorted(assigned.items()))}
levels={}
for level in core.LEVELS:
 items=[t for t in by_target.values() if t['level']==level];ordered,_=select_target_ids(items,len(items) or 1)
 levels[level]={'knownEligibleTargets':len(items),'sourceContextRefsInGraph':len({c['contextId'] for t in items for c in t['contexts']}),'greedyUpToThreeContexts':greedy(ordered,3),'greedyPrimaryOnly':greedy(ordered,1),'maximumPrimaryOnly':maximum_matching(ordered)}
report={'diagnosticVersion':1,'publicationSafe':False,'selectionChanged':False,'scope':'81 stored direct bilingual witnesses from accepted pl-ko and reversed ko-pl contexts; exported Polish ranks only','selectedMaterialSha256':w['sourceFileSha256'],'witnessFileSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'analysisScriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'knownRankSurfaces':len(ranks),'ambiguousRankSurfacesExcluded':len(w['ambiguousRankSurfaces']),'counters':dict(stats),'levels':levels,'limitations':['Partial source witness, not reconstruction of all 94 raw candidate rows or all source occurrences/ranks.','Maximum matching assumes one primary context per target; it does not preserve the original up-to-three-context allocation policy.','Counts from a different diagnostic subset cannot be subtracted from full-report losses to promise recoverable targets.','Joining existing reverse-direction source text/ref witnesses is diagnostic reuse, not machine translation or newly admitted supply.','Raw admitted pool plus its exact rank construction are needed to attribute every full selection loss or test a proposed policy on complete evidence.']}
(root/'validation/round15/census/ALLOCATION-WITNESS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('Counters',dict(stats))
for level,d in levels.items():print(level,{k:(v['memberships'] if isinstance(v,dict) else v) for k,v in d.items()})
